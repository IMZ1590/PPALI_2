#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$DIR"

echo "========================================================"
echo "  PPALI 2 Launcher (Linux)"
echo "========================================================"

error_exit() {
    echo ""
    echo "[ERROR] $1"
    read -p "Press Enter to exit..."
    exit 1
}

# 1. Check Python
if ! command -v python3 &> /dev/null; then
    error_exit "Python3 is not installed. Please install python3."
fi

# 2. Check/Create venv (Resilient Method)
if [ ! -f "venv/bin/pip" ]; then
    echo "[INFO] Creating virtual environment..."
    rm -rf venv
    python3 -m venv venv > /dev/null 2>&1
    
    if [ ! -f "venv/bin/pip" ]; then
        echo "[WARN] Standard venv creation failed. Retrying with workaround..."
        python3 -m venv --without-pip venv || error_exit "Failed to create bare venv."
        
        echo "[INFO] Downloading pip bootstrapper..."
        GET_PIP_URL="https://bootstrap.pypa.io/get-pip.py"
        if command -v curl &> /dev/null; then
            curl -sL "$GET_PIP_URL" -o get-pip.py
        elif command -v wget &> /dev/null; then
            wget -q "$GET_PIP_URL" -O get-pip.py
        else
            error_exit "Need 'curl' or 'wget' installed to download pip."
        fi
        
        echo "[INFO] Installing pip manually..."
        ./venv/bin/python get-pip.py > /dev/null 2>&1
        rm get-pip.py
        
        if [ ! -f "venv/bin/pip" ]; then
            error_exit "Manual pip install failed. Install 'python3-venv'."
        fi
    fi
    echo "[INFO] Installing dependencies..."
    ./venv/bin/pip install -r backend/requirements.txt || error_exit "Failed to install libraries."
else
    # Verify existing env
    ./venv/bin/python -c "import fastapi" > /dev/null 2>&1
    if [ $? -ne 0 ]; then
        echo "[INFO] Repairing dependencies..."
        ./venv/bin/pip install -r backend/requirements.txt || error_exit "Failed to repair libraries."
    fi
fi

# 3. Launch
echo "[INFO] Starting Backend..."
echo "[NOTE] The browser will open automatically."
echo "[INFO] Close this window to stop application (Ctrl+C)."

# Run in FOREGROUND so closing window kills it
./venv/bin/python backend/main.py

echo ""
read -p "Press Enter to exit..."
